# Warehouse Robots - Code Challenge

We have a number of warehouses with robot automation and we have implemented version 1 of a web service to control them.

For convenience the robot moves along a grid in the roof of the warehouse, and we have made sure that all of our warehouses are built so that the dimensions of the grid are 10 by 10. We've also made sure that all our warehouses are aligned along north-south and east-west axes.

All of the commands to the robot consist of a single capital letter, and different commands are delineated by whitespace.

The robot accepts the following commands:

* N moves North
* W moves West
* E moves East
* S moves South

Please note that coordinates on the grid are commonly referenced using a 2-element array consisting of the X and Y positions as such: \[X, Y\], where X and Y are displacements from the bottom left corner of the grid.

## Example command sequences

The following command will move the robot in a full square, returning it to where it started: 

"N E S W"

If the robot starts in the south-west corner of the warehouse then the following commands will move it to the middle of the warehouse:

"N E N E N E N E"

# Objectives

1. The tests are failing; Please fix them.
1. The movement command needs to be authorized; Please add some form of authorization.
1. Version 2 of our service needs to support warehouses that have more than one robot on separate grids; Implement this functionality.

Borrowed, with modifications, from The Guardian pair-programming interview exercises. https://github.com/guardian/pairing-tests

# Building

* We are using gradle as a build tool. The application is packaged into a jar and executed via the command line.
* This project is built with Java 8 and builds to a jar.
* Tests are run at build time - the rest of the implementation can be added after the initial tests are passing. 
* Typically, the easiest command to use on repeat is ```./gradlew build && java -jar build/libs/robotservice.jar``` from the root directory of the project. This will execute the jar if the tests are passing and allow you to test any new functionality. You can also run just the tests with `./gradlew test`.
