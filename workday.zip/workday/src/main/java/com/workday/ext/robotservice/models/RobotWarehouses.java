package com.workday.ext.robotservice.models;

import java.util.*;

public class RobotWarehouses {

    private Map<String, RobotWarehouse> warehouses = new HashMap<>();

    public RobotWarehouses() {
    	warehouses.put("wh3", new RobotWarehouse(new int[]{0, 0}));
        warehouses.put("wh1", new RobotWarehouse(new int[]{0, 0}));
        warehouses.put("wh2", new RobotWarehouse(new int[]{0, 0}));
        
    }

    public RobotWarehouse getWarehouse(String warehouseId) {
        return warehouses.get(warehouseId);
    }

    public void updateWarehouse(String warehouseId, int[] robotPosition) {
        warehouses.get(warehouseId).setRobotPosition(robotPosition);
    }

    public Map<String, RobotWarehouse> getWarehouses() {
        return this.warehouses;
    }
}
