package com.workday.ext.robotservice.models;

import java.util.HashMap;
import java.util.Map;

public class RobotWarehouse {
	
	private Map<String, int[]> robots = new HashMap<>();
	
    public RobotWarehouse(int[] robotPosition) {
    	robots.put("rb1", robotPosition);
    }
    
    public RobotWarehouse(int[] robotPosition, String robotid) {
        robots.put(robotid, robotPosition);
    }

    public int[] getRobotPosition() {
        return this.robots.get("rb1").clone();
    }
    
    public int[] getRobotPosition(String robotId) {
    	if (robotId == null) {
    		return getRobotPosition();
    	}
        return this.robots.get(robotId).clone();
    }

    public void setRobotPosition(int[] robotPosition) {
    	robots.put("rb1", robotPosition.clone());
    }
    
    public void setRobotPosition(int[] robotPosition, String robotId) {
    	robots.put(robotId, robotPosition.clone());
    }
    
}
