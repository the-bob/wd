package com.workday.ext.robotservice.controllers;

import com.workday.ext.robotservice.models.RobotWarehouse;
import com.workday.ext.robotservice.models.RobotWarehouses;

public class WarehouseController {

    private RobotWarehouses warehouses;

    public WarehouseController() {
        warehouses = new RobotWarehouses();
    }

    public RobotWarehouses getAllWarehouses() {
        return warehouses;
    }

    

    public RobotWarehouse getWarehouse(String warehouseId, String robotId) {
    	return warehouses.getWarehouse(warehouseId);
    }
    
    public RobotWarehouse getWarehouse(String warehouseId) {
    	return warehouses.getWarehouse(warehouseId);
    }

    public void moveRobot(String warehouseId, String moveSequence, String robotId) {
        int[] robotPosition = warehouses.getWarehouse(warehouseId).getRobotPosition(robotId);

        String[] moves = moveSequence.split(" ");
        
        for(int i = 0; i < moves.length; i++) {
            switch(moves[i].toLowerCase()) {
                case "n":
                    robotPosition[1] = robotPosition[1] == 10 ? robotPosition[1] : robotPosition[1] + 1;
                    break;
                case "s":
                    robotPosition[1] = robotPosition[1] == 0 ? robotPosition[1] : robotPosition[1] - 1;
                    break;
                case "e":
                    robotPosition[0] = robotPosition[0] == 10 ? robotPosition[0] : robotPosition[0] + 1;
                    break;
                case "w":
                    robotPosition[0] = robotPosition[0] == 0 ? robotPosition[0] : robotPosition[0] - 1;
                    break;
                default:
                    // ignore non-moves in sequence
                	// should we throw an exception
                	throw new IllegalArgumentException("INVALID_MOVE");
            }
        }
        warehouses.getWarehouse(warehouseId).setRobotPosition(robotPosition);
    }
    
    public void moveRobot(String warehouseId, String moveSequence) {
        this.moveRobot(warehouseId, moveSequence, null);
    }
}
