package com.workday.ext.robotservice.routes;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.workday.ext.robotservice.controllers.WarehouseController;
import com.workday.ext.robotservice.misc.MoveSequence;
import com.workday.ext.robotservice.models.RobotWarehouse;
import com.workday.ext.robotservice.models.RobotWarehouses;

@RestController
public class WarehouseRoutes {

    // one extra layer of abstraction to avoid clutter
	private static Map<String, WarehouseController> warehouseRobotMap = new HashMap<String, WarehouseController>();
	
    private static WarehouseController warehouseController = new WarehouseController();
    
    static Set<String> authTokens = new HashSet<>();
    
    static {
    	authTokens.add("ID valid-super-encrypted-user-token");
    	warehouseRobotMap.put("rb1", warehouseController);
    }
    
    static void auth(Map<String, String> header) {
    	String authToken = header.get("Authorization");
		if (authToken == null) {
    		throw new ResponseStatusException(
	                HttpStatus.UNAUTHORIZED, "UNAUTHORIZED");
    	}
    	else {
    		if (!authTokens.contains(authToken)) {
    			throw new ResponseStatusException(
    	                HttpStatus.FORBIDDEN, "FORBIDDEN");
    		}
    	}
    } 
    
    @GetMapping(value="/", produces="application/json")
    @ResponseBody
    public RobotWarehouses index() {
        return warehouseController.getAllWarehouses();
    }

    @GetMapping(value="/warehouses/{warehouseId}", produces="application/json")
    @ResponseBody
    public RobotWarehouse getWarehouse(@PathVariable("warehouseId") String warehouseId) {
        RobotWarehouse warehouse = warehouseController.getWarehouse(warehouseId);
        if (warehouse == null) {
        	// TODO put logging
        	throw new ResponseStatusException(
	                HttpStatus.NOT_FOUND, "WAREHOUSE_NOT_FOUND");
        }
		return warehouse;
    }

    @GetMapping(value="/warehouses/{warehouseId}/robot", produces="application/json")
    @ResponseBody
    public RobotWarehouse getRobot(@PathVariable("warehouseId") String warehouseId, @RequestHeader Map<String, String> header) {
    	auth(header);
        return warehouseController.getWarehouse(warehouseId);
    }

    @PutMapping("/warehouses/{warehouseId}/robot")
    @ResponseBody
    public RobotWarehouse moveRobot(@PathVariable("warehouseId") String warehouseId,
                         @RequestBody MoveSequence moveSequence, @RequestHeader Map<String, String> header) {
    	auth(header);
        try {
        	warehouseController.moveRobot(warehouseId, moveSequence.getMoveSequence());
		} catch (IllegalArgumentException e) {
			throw new ResponseStatusException(
	                HttpStatus.BAD_REQUEST, "ILLEGAL_MOVE", e);
		}
        return warehouseController.getWarehouse(warehouseId);
    }
    
    
    @PutMapping("/warehouses/{warehouseId}/robot/{robotId}")
    @ResponseBody
    public RobotWarehouse moveRobot(@PathVariable("warehouseId") String warehouseId,
                         @RequestBody MoveSequence moveSequence, @PathVariable("robotId") String robotId, @RequestHeader Map<String, String> header) {
    	auth(header);
        try {
        	warehouseController.moveRobot(warehouseId, moveSequence.getMoveSequence(), robotId);
		} catch (IllegalArgumentException e) {
			throw new ResponseStatusException(
	                HttpStatus.BAD_REQUEST, "ILLEGAL_MOVE", e);
		}
        return warehouseController.getWarehouse(warehouseId);
    }
    
    @GetMapping(value="/warehouses/{warehouseId}/robot/{robotId}", produces="application/json")
    @ResponseBody
    public int[] getRobot(@PathVariable("warehouseId") String warehouseId, @PathVariable("robotId") String robotId,
    		@RequestHeader Map<String, String> header) {
    	//auth(header);
    	return warehouseController.getWarehouse(warehouseId).getRobotPosition(robotId);
    }
}
