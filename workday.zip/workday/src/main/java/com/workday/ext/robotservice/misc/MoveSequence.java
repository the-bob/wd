package com.workday.ext.robotservice.misc;

// used for JSON deserialization in HTTP requests
public class MoveSequence {

    private String moveSequence;

    public MoveSequence() {}

    public MoveSequence(String moveSequence) {
        this.moveSequence = moveSequence;
    }

    public String getMoveSequence() {
        return this.moveSequence;
    }

    public void setMoveSequence(String moveSequence) {
        this.moveSequence = moveSequence;
    }
}
