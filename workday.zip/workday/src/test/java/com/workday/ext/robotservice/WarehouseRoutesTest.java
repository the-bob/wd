package com.workday.ext.robotservice;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.workday.ext.robotservice.misc.MoveSequence;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class WarehouseRoutesTest {

    @Autowired
    private MockMvc mvc;

    @Test
    public void shouldFetchAllWarehousesData() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/").accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.warehouses.*", hasSize(3)));
    }

    @Test
    public void shouldFetchAWarehouse() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/warehouses/wh1").accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void shouldGive404ForInvalidWarehouseID() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/warehouses/bogus-id"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void shouldFetchRobotWarehousePositionData() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/warehouses/wh1/robot")
        		.header("Authorization", "ID valid-super-encrypted-user-token")
        		.accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void shouldRejectUnauthorizedRequests() throws Exception {
        MoveSequence moveSequence = new MoveSequence("N N");
        mvc.perform(MockMvcRequestBuilders.put("/warehouses/wh2/robot")
                .content(asJsonString(moveSequence))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void shouldRejectBadAuthorization() throws Exception {
        MoveSequence moveSequence = new MoveSequence("N N");
        mvc.perform(MockMvcRequestBuilders.put("/warehouses/wh2/robot")
                .header("Authorization", "ID invalid-super-encrypted-user-token")
                .content(asJsonString(moveSequence))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isForbidden());
    }

    @Test
    public void shouldRejectAnInvalidMovementSequence() throws Exception {
        MoveSequence moveSequence = new MoveSequence("A");
        mvc.perform(MockMvcRequestBuilders.put("/warehouses/wh2/robot")
        		.header("Authorization", "ID valid-super-encrypted-user-token")
                .content(asJsonString(moveSequence))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void shouldChangeThePositionOfAWarehouseRobot() throws Exception {
        MoveSequence moveSequence = new MoveSequence("E N");
        mvc.perform(MockMvcRequestBuilders.put("/warehouses/wh2/robot")
        		.header("Authorization", "ID valid-super-encrypted-user-token")
                .content(asJsonString(moveSequence))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.robotPosition[0]", is(1)))
                .andExpect(jsonPath("$.robotPosition[1]", is(1)));
    }

    @Test
    public void shouldRetainTheLastPositionOfAWarehouseRobot() throws Exception {
        MoveSequence moveSequence1 = new MoveSequence("E E N");
        MoveSequence moveSequence2 = new MoveSequence("E S s s");

        mvc.perform(MockMvcRequestBuilders.put("/warehouses/wh1/robot")
        		.header("Authorization", "ID valid-super-encrypted-user-token")
                .content(asJsonString(moveSequence1))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.robotPosition[0]", is(2)))
                .andExpect(jsonPath("$.robotPosition[1]", is(1)));
        mvc.perform(MockMvcRequestBuilders.put("/warehouses/wh1/robot")
        		.header("Authorization", "ID valid-super-encrypted-user-token")
                .content(asJsonString(moveSequence2))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.robotPosition[0]", is(3)))
                .andExpect(jsonPath("$.robotPosition[1]", is(0)));
    }

    @Test
    public void shouldFetchCurrentPositionOfSpecificRobot() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/warehouses/wh3/robot/rb1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void shouldChangePositionOfASpecificRobot() throws Exception {
        MoveSequence moveSequence = new MoveSequence("E N");
        mvc.perform(MockMvcRequestBuilders.put("/warehouses/wh3/robot/rb1")
                .header("Authorization", "ID valid-super-encrypted-user-token")
                .content(asJsonString(moveSequence))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.robotPosition[0]", is(1)))
                .andExpect(jsonPath("$.robotPosition[1]", is(1)));
    }
    
    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
